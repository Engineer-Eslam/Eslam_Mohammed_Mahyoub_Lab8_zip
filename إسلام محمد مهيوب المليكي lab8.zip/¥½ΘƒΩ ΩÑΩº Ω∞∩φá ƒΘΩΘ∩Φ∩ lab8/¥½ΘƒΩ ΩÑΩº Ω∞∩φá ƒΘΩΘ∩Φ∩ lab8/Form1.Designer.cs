﻿namespace إسلام_محمد_مهيوب_المليكي_lab8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAll = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.txtAllLength = new System.Windows.Forms.TextBox();
            this.txtSelectLength = new System.Windows.Forms.TextBox();
            this.txtWordCount = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.buttonreplace = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textreplace = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSearchAll = new System.Windows.Forms.Button();
            this.buttonsearch2 = new System.Windows.Forms.Button();
            this.buttonsearch1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.buttonsearch = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonword = new System.Windows.Forms.Button();
            this.buttonchar = new System.Windows.Forms.Button();
            this.txtCopyPast = new System.Windows.Forms.TextBox();
            this.buttonretreat = new System.Windows.Forms.Button();
            this.buttonpaste = new System.Windows.Forms.Button();
            this.listBoxchar = new System.Windows.Forms.ListBox();
            this.listBoxword = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAll
            // 
            this.txtAll.Location = new System.Drawing.Point(16, 15);
            this.txtAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAll.Multiline = true;
            this.txtAll.Name = "txtAll";
            this.txtAll.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAll.Size = new System.Drawing.Size(879, 78);
            this.txtAll.TabIndex = 0;
            this.txtAll.Text = "من اهم استخدامات لفه السي شارب برمجة تطبيقات سطح المكتب وبرمجه تطبيقات الهواتف ال" +
    "ذكية وصناعة الألعاب";
            this.txtAll.TextChanged += new System.EventHandler(this.txtAll_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(762, 116);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "طول النص كامل";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(626, 116);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 28);
            this.button2.TabIndex = 2;
            this.button2.Text = "طول النص المحدد";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(489, 117);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(129, 28);
            this.button3.TabIndex = 3;
            this.button3.Text = "عدد الكلمات";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.word_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(130, 116);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(62, 28);
            this.button4.TabIndex = 6;
            this.button4.Text = "نسخ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(198, 116);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.button5.Size = new System.Drawing.Size(129, 28);
            this.button5.TabIndex = 5;
            this.button5.Text = "إلغاء التحديد";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(335, 116);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(146, 28);
            this.button6.TabIndex = 4;
            this.button6.Text = "حذف النص المحدد";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(66, 116);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(62, 28);
            this.button7.TabIndex = 7;
            this.button7.Text = "قص";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1, 116);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(62, 28);
            this.button8.TabIndex = 8;
            this.button8.Text = "تنضيف";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // txtAllLength
            // 
            this.txtAllLength.Location = new System.Drawing.Point(762, 151);
            this.txtAllLength.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAllLength.Name = "txtAllLength";
            this.txtAllLength.Size = new System.Drawing.Size(127, 23);
            this.txtAllLength.TabIndex = 9;
            this.txtAllLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSelectLength
            // 
            this.txtSelectLength.Location = new System.Drawing.Point(626, 151);
            this.txtSelectLength.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSelectLength.Name = "txtSelectLength";
            this.txtSelectLength.Size = new System.Drawing.Size(127, 23);
            this.txtSelectLength.TabIndex = 10;
            this.txtSelectLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtWordCount
            // 
            this.txtWordCount.Location = new System.Drawing.Point(489, 151);
            this.txtWordCount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtWordCount.Name = "txtWordCount";
            this.txtWordCount.Size = new System.Drawing.Size(127, 23);
            this.txtWordCount.TabIndex = 11;
            this.txtWordCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(242, 151);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(239, 28);
            this.button9.TabIndex = 12;
            this.button9.Text = "طول النص كامل بدون الفراغات";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1, 151);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(233, 28);
            this.button10.TabIndex = 13;
            this.button10.Text = "طول النص المحدد بدون فراغات";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // buttonreplace
            // 
            this.buttonreplace.Location = new System.Drawing.Point(94, 78);
            this.buttonreplace.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonreplace.Name = "buttonreplace";
            this.buttonreplace.Size = new System.Drawing.Size(177, 28);
            this.buttonreplace.TabIndex = 14;
            this.buttonreplace.Text = "استبدال";
            this.buttonreplace.UseVisualStyleBackColor = true;
            this.buttonreplace.Click += new System.EventHandler(this.button11_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textreplace);
            this.panel1.Controls.Add(this.buttonreplace);
            this.panel1.Location = new System.Drawing.Point(550, 206);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(350, 123);
            this.panel1.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "النص الجديد";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(282, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "استبدال";
            // 
            // textreplace
            // 
            this.textreplace.Location = new System.Drawing.Point(94, 46);
            this.textreplace.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textreplace.Name = "textreplace";
            this.textreplace.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textreplace.Size = new System.Drawing.Size(175, 23);
            this.textreplace.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnSearchAll);
            this.panel2.Controls.Add(this.buttonsearch2);
            this.panel2.Controls.Add(this.buttonsearch1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtSearch);
            this.panel2.Controls.Add(this.buttonsearch);
            this.panel2.Location = new System.Drawing.Point(16, 206);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(487, 158);
            this.panel2.TabIndex = 18;
            // 
            // btnSearchAll
            // 
            this.btnSearchAll.Location = new System.Drawing.Point(50, 114);
            this.btnSearchAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSearchAll.Name = "btnSearchAll";
            this.btnSearchAll.Size = new System.Drawing.Size(390, 28);
            this.btnSearchAll.TabIndex = 20;
            this.btnSearchAll.Text = "البحث لجميع الأنماط المطابقه";
            this.btnSearchAll.UseVisualStyleBackColor = true;
            this.btnSearchAll.Click += new System.EventHandler(this.btnSearchAll_Click);
            // 
            // buttonsearch2
            // 
            this.buttonsearch2.Location = new System.Drawing.Point(16, 78);
            this.buttonsearch2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonsearch2.Name = "buttonsearch2";
            this.buttonsearch2.Size = new System.Drawing.Size(140, 28);
            this.buttonsearch2.TabIndex = 19;
            this.buttonsearch2.Text = "بحث عن السابق";
            this.buttonsearch2.UseVisualStyleBackColor = true;
            this.buttonsearch2.Click += new System.EventHandler(this.buttonsearch2_Click);
            // 
            // buttonsearch1
            // 
            this.buttonsearch1.Location = new System.Drawing.Point(171, 78);
            this.buttonsearch1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonsearch1.Name = "buttonsearch1";
            this.buttonsearch1.Size = new System.Drawing.Size(140, 28);
            this.buttonsearch1.TabIndex = 18;
            this.buttonsearch1.Text = "بحث عن التالي";
            this.buttonsearch1.UseVisualStyleBackColor = true;
            this.buttonsearch1.Click += new System.EventHandler(this.buttonsearch1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "النص المراد البحث عنه";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(447, -2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "بحث";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(182, 37);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtSearch.Size = new System.Drawing.Size(175, 23);
            this.txtSearch.TabIndex = 16;
            // 
            // buttonsearch
            // 
            this.buttonsearch.Location = new System.Drawing.Point(325, 78);
            this.buttonsearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonsearch.Name = "buttonsearch";
            this.buttonsearch.Size = new System.Drawing.Size(140, 28);
            this.buttonsearch.TabIndex = 14;
            this.buttonsearch.Text = "بحث";
            this.buttonsearch.UseVisualStyleBackColor = true;
            this.buttonsearch.Click += new System.EventHandler(this.buttonsearch_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(308, 370);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "احرف الكلمة المحددة";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 370);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "كلمات الجملة المحددة";
            // 
            // buttonword
            // 
            this.buttonword.Location = new System.Drawing.Point(100, 390);
            this.buttonword.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonword.Name = "buttonword";
            this.buttonword.Size = new System.Drawing.Size(130, 28);
            this.buttonword.TabIndex = 21;
            this.buttonword.Text = "عرض";
            this.buttonword.UseVisualStyleBackColor = true;
            this.buttonword.Click += new System.EventHandler(this.buttonword_Click);
            // 
            // buttonchar
            // 
            this.buttonchar.Location = new System.Drawing.Point(313, 390);
            this.buttonchar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonchar.Name = "buttonchar";
            this.buttonchar.Size = new System.Drawing.Size(122, 28);
            this.buttonchar.TabIndex = 22;
            this.buttonchar.Text = "عرض";
            this.buttonchar.UseVisualStyleBackColor = true;
            this.buttonchar.Click += new System.EventHandler(this.buttonchar_Click);
            // 
            // txtCopyPast
            // 
            this.txtCopyPast.Location = new System.Drawing.Point(537, 394);
            this.txtCopyPast.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCopyPast.Multiline = true;
            this.txtCopyPast.Name = "txtCopyPast";
            this.txtCopyPast.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtCopyPast.Size = new System.Drawing.Size(354, 131);
            this.txtCopyPast.TabIndex = 25;
            // 
            // buttonretreat
            // 
            this.buttonretreat.Location = new System.Drawing.Point(537, 349);
            this.buttonretreat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonretreat.Name = "buttonretreat";
            this.buttonretreat.Size = new System.Drawing.Size(99, 28);
            this.buttonretreat.TabIndex = 26;
            this.buttonretreat.Text = "تراجع";
            this.buttonretreat.UseVisualStyleBackColor = true;
            this.buttonretreat.Click += new System.EventHandler(this.buttonretreat_Click);
            // 
            // buttonpaste
            // 
            this.buttonpaste.Location = new System.Drawing.Point(792, 349);
            this.buttonpaste.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonpaste.Name = "buttonpaste";
            this.buttonpaste.Size = new System.Drawing.Size(99, 28);
            this.buttonpaste.TabIndex = 27;
            this.buttonpaste.Text = "لصق";
            this.buttonpaste.UseVisualStyleBackColor = true;
            this.buttonpaste.Click += new System.EventHandler(this.buttonpaste_Click);
            // 
            // listBoxchar
            // 
            this.listBoxchar.FormattingEnabled = true;
            this.listBoxchar.ItemHeight = 16;
            this.listBoxchar.Location = new System.Drawing.Point(298, 425);
            this.listBoxchar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBoxchar.Name = "listBoxchar";
            this.listBoxchar.Size = new System.Drawing.Size(158, 100);
            this.listBoxchar.TabIndex = 28;
            // 
            // listBoxword
            // 
            this.listBoxword.FormattingEnabled = true;
            this.listBoxword.ItemHeight = 16;
            this.listBoxword.Location = new System.Drawing.Point(80, 425);
            this.listBoxword.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBoxword.Name = "listBoxword";
            this.listBoxword.Size = new System.Drawing.Size(158, 100);
            this.listBoxword.TabIndex = 29;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 538);
            this.Controls.Add(this.listBoxword);
            this.Controls.Add(this.listBoxchar);
            this.Controls.Add(this.buttonpaste);
            this.Controls.Add(this.buttonretreat);
            this.Controls.Add(this.txtCopyPast);
            this.Controls.Add(this.buttonchar);
            this.Controls.Add(this.buttonword);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.txtWordCount);
            this.Controls.Add(this.txtSelectLength);
            this.Controls.Add(this.txtAllLength);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtAll);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion
        private System.Windows.Forms.TextBox txtAll;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox txtAllLength;
        private System.Windows.Forms.TextBox txtSelectLength;
        private System.Windows.Forms.TextBox txtWordCount;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button buttonreplace;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textreplace;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonsearch2;
        private System.Windows.Forms.Button buttonsearch1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button buttonsearch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonword;
        private System.Windows.Forms.Button buttonchar;
        private System.Windows.Forms.TextBox txtCopyPast;
        private System.Windows.Forms.Button buttonretreat;
        private System.Windows.Forms.Button buttonpaste;
        private System.Windows.Forms.ListBox listBoxchar;
        private System.Windows.Forms.ListBox listBoxword;
        private System.Windows.Forms.Button btnSearchAll;
    }
}

